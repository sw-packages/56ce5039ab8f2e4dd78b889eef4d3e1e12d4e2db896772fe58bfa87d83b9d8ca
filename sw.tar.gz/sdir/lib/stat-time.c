#include <config.h>
#define _GL_STAT_TIME_INLINE _GL_EXTERN_INLINE
#include "stat-time.h"
